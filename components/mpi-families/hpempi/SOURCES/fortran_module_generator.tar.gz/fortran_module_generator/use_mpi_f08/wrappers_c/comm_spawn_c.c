/*
 *    Copyright 2017 (C) Hewlett Packard Enterprise Development LP
 *    All rights reserved.
 *
 *    HPE RESERVES THE RIGHT TO WITHDRAW, MODIFY, OR REPLACE THIS SOFTWARE AT
 *    ANY TIME, WITHOUT NOTICE. THE SOFTWARE IS "AS IS." IN CONNECTION WITH OR
 *    ARISING IN RELATION TO THE SOFTWARE AND/OR THIS NOTICE, (1) IN NO EVENT
 *    SHALL HPE OR ITS SUPPLIERS BE LIABLE FOR ANY SPECIAL, CONSEQUENTIAL,
 *    INCIDENTAL OR INDIRECT DAMAGES, EVEN IF PRE-ADVISED OF THEIR PROSPECT,
 *    HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY; AND, (2) HPE AND
 *    ITS SUPPLIERS DISCLAIM ANY AND ALL LIABILITY FOR: (a) WARRANTIES AND
 *    CONDITIONS, WHETHER EXPRESSED, IMPLIED, OR STATUTORY,  ARISING IN RELATION
 *    TO THE SOFTWARE AND/OR THIS NOTICE, INCLUDING WITHOUT LIMITATION ANY
 *    WARRANTY AND/OR CONDITION OF ERROR-FREE AND/OR UNINTERRUPTED OPERATION,
 *    MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE,
 *    AND NON-INFRINGEMENT; AND (b) INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
 *    OR CONSEQUENTIAL DAMAGES RELATING TO THE SOFTWARE, ITS USE, MISUSE,
 *    AND/OR FAILURE OF USE. ALL OF THE FOREGOING APPLY NOTWITHSTANDING THE
 *    FAILURE OF ESSENTIAL PURPOSE OF ANY CONTRACTUAL REMEDY.
 */

#include "mpi.h"
#include "mpich_defines.h"
#include "cdesc.h"

int MPIR_Comm_spawn_c(const char *command, char *argv_f, int maxprocs, MPI_Info info, int root,
        MPI_Comm comm, MPI_Comm *intercomm, int* array_of_errcodes, int argv_elem_len)
{
    int mpi_errno = MPI_SUCCESS;
    char** argv_c = NULL;

    if ((char**)argv_f == MPI_ARGV_NULL) {
        argv_c = MPI_ARGV_NULL;
    } else {
        mpi_errno = MPIR_Fortran_array_of_string_f2c(argv_f, &argv_c, argv_elem_len,
            0 /* Don't know size of argv_f */, 0);
        if (mpi_errno != MPI_SUCCESS) goto fn_fail;
    }

    mpi_errno = PMPI_Comm_spawn(command, argv_c, maxprocs, info, root, comm, intercomm, array_of_errcodes);

    if (argv_c != MPI_ARGV_NULL) {
        MPIU_Free(argv_c);
    }

fn_exit:
    return mpi_errno;
fn_fail:
    goto fn_exit;
}
