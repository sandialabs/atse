// Each rank prints out its nid, xyz coord, hostname, and cpu
// Kevin Pedretti, ktpedre@sandia.gov, October 2012

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sched.h>
#include <mpi.h>
#include <omp.h>

// #define CRAY_TOPO_INFO

#ifdef CRAY_TOPO_INFO
#include <rca_lib.h>
#endif

int main(int argc, char **argv)
{
    int me, npes, cpu, tid, num_threads;
#ifdef CRAY_TOPO_INFO
    int nid, x, y, z;
#endif
    char hostname[64];
    char my_string[4096];
    char *all_strings;
    int i;
    int tid_cpus[1024];

    MPI_Init(&argc, &argv);

    // Get my pe and num pes
    MPI_Comm_rank(MPI_COMM_WORLD, &me);
    MPI_Comm_size(MPI_COMM_WORLD, &npes);

    // Get my hostname
    gethostname(hostname, sizeof(hostname));

    // Get my cpu
    cpu = sched_getcpu();

#ifdef CRAY_TOPO_INFO
    // Get my nid
    rs_node_t node;
    rca_get_nodeid(&node);
    nid = (int)node.rs_node_s._node_id;

    // Get my x, y, z coordinate
    mesh_coord_t coord;
    rca_get_meshcoord((uint16_t)nid, &coord);
    x = coord.mesh_x;
    y = coord.mesh_y;
    z = coord.mesh_z;

    // Generate my info string
    sprintf(my_string, "%6i: %6i ( %2i %2i %2i  ) %s cpu %2i thread_cpus=[ ",
            me, nid, x, y, z, hostname, cpu);
#else
    // Generate my info string
    sprintf(my_string, "%6i: %s cpu %2i thread_cpus=[ ",
            me, hostname, cpu);
#endif

    // Run an OpenMP loop to get the cpu id that each omp thread is running on
#pragma omp parallel private(tid) shared(num_threads)
    {
        # pragma omp single
        {
            num_threads = omp_get_num_threads();
        }
        tid = omp_get_thread_num();
        tid_cpus[tid] = sched_getcpu();
    }

    // Tack on the list of omp cpu ids
    for (i = 0; i < num_threads; i++)
        sprintf(my_string + strlen(my_string), "%d ", tid_cpus[i]);
    sprintf(my_string + strlen(my_string), "]\n");

    // Rank 0 allocates memory to gather all info strings
    if (!me) {
        size_t size = npes * sizeof(my_string);
        all_strings = malloc(size);
        if (!all_strings) {
            printf("ERROR: malloc(%lu) failed\n", size);
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }

    // Gather all info strings to rank 0
    MPI_Gather(my_string, sizeof(my_string), MPI_CHAR,
               all_strings, sizeof(my_string), MPI_CHAR,
               0, MPI_COMM_WORLD);

    // Rank 0 prints out all info strings in sorted order by pe
    if (!me) {
        for (i = 0; i < npes; i++) {
            printf("%s", &all_strings[i * sizeof(my_string)]);
        }
    }

    MPI_Finalize();
    return EXIT_SUCCESS;
}
